# ALQATERA — hostinqə yerləşdirməyə hazır layihə

## Hazır olan funksiyalar
- Mobil uyğun ALQATERA mağazası və məhsul axtarışı
- Səbət və sifariş forması
- Müştəri qeydiyyatı və giriş
- Yalnız bir baş admin: məhsul əlavə etmək, şəkil yükləmək, məhsulu vitrindən çıxarmaq
- Sifarişləri görmək və statuslarını dəyişmək
- SQLite verilənlər bazası, parol hash-i, CSRF yoxlaması, təhlükəsiz sessiya parametrləri
- PWA manifesti və service worker
- VAPID açarları qurulduqda baş admin telefonuna yeni sifariş push bildirişi

## Render-də yerləşdirmə

1. ZIP-i kompüterdə aç və `ALQATERA` qovluğunun içindəkiləri GitHub repozitoriyasına yüklə.
2. Render-də **New + → Web Service** seç və GitHub repozitoriyanı qoş.
3. Root Directory: boş saxla (əgər repozitoriyada birbaşa `app.py` və `requirements.txt` görünürsə). Əgər repozitoriyada `ALQATERA` alt qovluğu varsa, Root Directory = `ALQATERA`.
4. Runtime: Python.
5. Build Command: `pip install -r requirements.txt`
6. Start Command: `gunicorn app:app`
7. Environment Variables bölməsində bunları əlavə et:
   - `SECRET_KEY` — uzun, təsadüfi və məxfi dəyər
   - `OWNER_EMAIL` — baş admin üçün sənin Gmail ünvanın
   - `OWNER_PASSWORD` — güclü, unikal admin şifrəsi (heç kimə göndərmə)
   - `DATABASE_PATH` — `/var/data/alqatera.db`
   - `UPLOADS_PATH` — `/var/data/uploads`
8. Render xidmətinin **Disks** bölməsində mount path `/var/data` olan persistent disk yarat. Disk olmadan SQLite bazası və yüklənən şəkillər yenidən deploy zamanı itə bilər.
9. Deploy tamamlandıqda Render sənə `https://...onrender.com` formasında real ünvan verəcək. Bu ünvanı Chrome-da aç və Instagram bio-ya əlavə et.

## Push bildirişlərini aktiv etmək
Push üçün VAPID açarları lazımdır. Bir dəfə kompüterdə `pywebpush`/VAPID aləti ilə public/private key cütü yarat və Render Environment Variables bölməsinə:
- `VAPID_PUBLIC_KEY`
- `VAPID_PRIVATE_KEY`
- `VAPID_CLAIMS_EMAIL` (əlaqə e-poçtu, məsələn `mailto:...`)
əlavə et. Private key-i heç kimə göndərmə. Sonra mağazaya baş admin kimi daxil ol, `/admin` səhifəsində **Bildirişləri aktiv et** düyməsini bas və brauzerdə bildiriş icazəsi ver. Bu versiyada bildiriş yalnız baş admin hesabına abunə edilmiş cihazlara göndərilir.

## Vacib məhdudiyyətlər
- Bu paket Google OAuth düyməsi deyil; baş admin Gmail ünvanı + ayrıca təyin etdiyin şifrə ilə daxil olur. Google hesabının öz giriş pəncərəsi üçün ayrıca OAuth Client ID/Secret və domen konfiqurasiyası lazımdır.
- Kartla onlayn ödəniş qoşulmayıb. Ödəniş provayderi (məsələn, yerli bank/ödəniş xidməti) ilə rəsmi merchant hesabı, API açarları və webhook tələb olunur. Bu məlumatlar olmadan real ödəniş inteqrasiyası aktiv edilə bilməz. İndiki sifariş axını sifarişi qəbul edir, ödəniş tutmur.
- E-poçt/SMS parol bərpası, sifariş spamına qarşı əlavə limitlər və istehsal səviyyəli monitorinq ayrıca iş tələb edir.
- Canlıya çıxmazdan əvvəl valideynin/etibarlı böyüyün köməyi ilə hostinq və ödəniş hesablarını qur. Şifrə, API açarı və təsdiq kodlarını heç kimlə paylaşma.

## Lokal yoxlama
`pip install -r requirements.txt` sonra `gunicorn app:app` və ya `python app.py`.
